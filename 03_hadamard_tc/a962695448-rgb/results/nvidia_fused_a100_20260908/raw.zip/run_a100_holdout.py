"""Run the fixed 52-case fused comparison on A100 using unchanged V2 numeric checks."""
import argparse
import gc
import json
import os
from pathlib import Path
import platform
import random
import re
import sys
import traceback
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'revised_v2'))
import checks_v2 as checks
import measurement_helpers as measure
from run_regressions import verify_sources

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--regression-report',type=Path,required=True)
    parser.add_argument('--reference-repo',type=Path,required=True)
    parser.add_argument('--run-index',type=int,choices=(1,2,3),required=True)
    parser.add_argument('--json',type=Path,required=True)
    args=parser.parse_args()
    assert not args.json.exists()
    args.json.parent.mkdir(parents=True,exist_ok=True)
    samples=args.json.with_name(args.json.stem+'_sample_buffers.json')
    report={'status':'RUNNING','started_utc':measure.utc(),'pid':os.getpid(),'run_index':args.run_index,'correctness':[],'benchmarks':[],'actual_gpu_execution':False,'scope':'New A100 run of the fixed 52-case V2 protocol; no imported 4090 results'}
    buffers={}
    def save(): args.json.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    code=1
    try:
        assert __debug__ and sys.flags.optimize==0
        verify_sources()
        regression=json.loads(args.regression_report.read_text())
        assert regression['status']=='PASS' and regression['holdout_allowed'] is True
        assert regression['source_manifest_sha256']==measure.sha(ROOT/'source_manifest.json')
        report.update(source_commit=json.loads((ROOT/'source_manifest.json').read_text())['source_commit'],source_manifest_sha256=measure.sha(ROOT/'source_manifest.json'),regression_report_sha256=measure.sha(args.regression_report),protocol_sha256=measure.sha(ROOT/'revised_v2/protocol_v2.json'),before=measure.snapshot())
        import numpy as np
        import torch
        import fast_hadamard_transform as ref
        import fast_hadamard_transform_cuda as backend
        assert torch.cuda.device_count()==1 and 'A100' in torch.cuda.get_device_name() and list(torch.cuda.get_device_capability())==[8,0]
        assert os.environ['TORCH_CUDA_ARCH_LIST']=='8.0'
        report['reference']=checks.original_checks.reference_tools.provenance(ref,backend,args.reference_repo)
        assert report['reference']['commit']=='e7706faf8d1c3b9f241e36860640ad1dac644ede'
        op=checks.original_checks.load_production()
        assert measure.sha(op.__file__)==regression['binaries']['production_extension']['sha256']
        build=(ROOT/'build/production/build.ninja').read_text()
        assert 'sm_80' in build and 'compute_80' in build
        assert re.search(r'(?:--|-)(?:use_fast_math|ftz(?:=|\s+)true)(?:\s|$)',build) is None
        report['environment']={'python':platform.python_version(),'torch':torch.__version__,'torch_cuda':torch.version.cuda,'numpy':np.__version__,'gpu':torch.cuda.get_device_name(),'sm':[8,0],'extension_sha256':measure.sha(op.__file__),'build_ninja_sha256':measure.sha(ROOT/'build/production/build.ninja')}
        protocol=json.loads((ROOT/'revised_v2/protocol_v2.json').read_text())
        spec=protocol['holdout']
        cases=[{'dtype':d,'rows':m,'dim':256,'shape':[m,256],'normalized':n,'scale':0.0625 if n else 1.0} for d in spec['dtypes'] for m in spec['rows'] for n in spec['normalized']]
        assert len(cases)==52
        random.Random(92700+args.run_index).shuffle(cases)
        report['configuration_order']=cases
        report['actual_gpu_execution']=True
        with torch.inference_mode():
            for case in cases:
                entry={**case,'checks':[]};report['correctness'].append(entry)
                for pattern,seeds in spec['patterns_and_seeds'].items():
                    for seed in seeds:
                        for offset in (0,2):
                            report['active_context']={**case,'pattern':pattern,'seed':seed,'pointer_mod16':offset}
                            entry['checks'].append(checks.check_input(torch,np,op,ref.hadamard_transform,case,pattern,seed,offset,buffers))
                print('CHECKED',json.dumps(case),flush=True)
            for index,case in enumerate(cases):
                dtype=torch.float16 if case['dtype']=='fp16' else torch.bfloat16
                x=checks.original_checks.reference_tools.make_input(torch,case['shape'],dtype,'normal',2026,'cuda')
                assert x.data_ptr()%16==0
                functions={'original':lambda:op.hadamard_int4(x,case['scale'],128),'contiguous256':lambda:op.hadamard_int4(x,case['scale'],128,'contiguous256')}
                timing=measure.measure_graph(torch,functions,args.run_index,index,protocol['timing'])
                report['benchmarks'].append({**case,'mode':'fused_int4','configuration_index':index,**timing})
                gc.collect();save();print('TIMED',json.dumps(case),flush=True)
        verify_sources()
        report['summary']={'distinct_configurations':52,'correctness_input_conditions':sum(len(e['checks']) for e in report['correctness']),'graph_comparisons':len(report['benchmarks'])}
        assert report['summary']['correctness_input_conditions']==728
        report['status']='PASS';code=0
    except Exception as error:
        report.update(status='FAIL',error=repr(error),traceback=traceback.format_exc())
        if hasattr(error,'certificate'): report['failed_certificate']=error.certificate
        print(report['traceback'],flush=True)
    finally:
        samples.write_text(json.dumps(buffers,sort_keys=True,separators=(',',':'))+'\n',encoding='utf-8')
        report['sample_buffers']={'file':samples.name,'sha256':measure.sha(samples),'buffers':len(buffers)}
        report.update(after=measure.snapshot(),exit_code=code,finished_utc=measure.utc());save()
    print(json.dumps({'status':report['status'],'summary':report.get('summary')}),flush=True)
    return code

if __name__=='__main__': raise SystemExit(main())
